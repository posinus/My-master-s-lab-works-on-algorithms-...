#include <stdio.h>
#include <stdlib.h>

int top = -1;

typedef struct Tree {
	int key;
	struct Tree *left, *right;
}NODE;

NODE *stack[100];

NODE *root=NULL;

void create(int k) {
	NODE *p=(NODE*)malloc(sizeof(NODE));
	NODE *q=root, *r;
	int ch;
	p->key=k;
	p->left=p->right=NULL;
	if(!root){
		root=p;
		return;
	}
	while(q){
		r=q;
		printf("%d will be at the left subtree or right subtree of %d (0/1) : ", k, q->key);
		scanf("%d", &ch);
		if(ch) q=q->right;
		else q=q->left;
	}
	if(ch) r->right=p;
	else r->left=p;
}

void push(NODE *element) {
	top++;
	stack[top] = element;
}

NODE* pop() {
	if(top==-1) return NULL;
	return stack[top--];
}

void inordertraversal() {
	NODE *p = root;
	while(p!=NULL || top!=-1) {
		while(p) {
			push(p);
			p=p->left;
		}
		p = pop();
		printf("%d ", p->key);
		p=p->right;
	}
}

int main() {
	int n, i;
	printf("Enter the number of elements : ");
	scanf("%d", &n);
	while(n>0){
		printf("Enter Element : ");
		scanf("%d", &i);
		create(i);
		n--;
	}
	inordertraversal();
	return 0;
}
