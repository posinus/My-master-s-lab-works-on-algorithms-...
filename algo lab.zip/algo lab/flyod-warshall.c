#include<stdio.h>

#include<conio.h>

#include<math.h>

int min(int,int);

void floydwarshal(int a[10][10],int n) //Warshall function
{

	int i,j,k;

	for (k=1;k<=n;k++)//loop for selected path

	 for (i=1;i<=n;i++)//loop for matrix

	 for (j=1;j<=n;j++)

	 a[i][j]=min(a[i][j],(a[i][k]+a[k][j]));//choosing between direct path or via path

}
int min(int a,int b)
{
	if (a<b)
	return (a);
	else
	return (b);
	
}

int main() {

	int a[10][10],n,e,u,v,i,j;


	printf ("\n Enter the number of vertices:");//Entering the  umber of vertices
	scanf("%d",&n);
	printf("\n Enter the adjacency matrix:\n");//Entering the adjecency matrix
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			scanf("%d",&a[i][j]);
			
		}
	}
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(a[i][j]==999)
			{
			printf("inf");	
			}
			else
			printf("%d\t",a[i][j]);
		}
		printf("\n");
	} 
	
	floydwarshal(a,n);

	printf("\n Matrix after Floyd-Warshall Operation: \n");//printing matrix

	for (i=1;i<=n;i++) {

		for (j=1;j<=n;j++)

		 printf("%d\t",a[i][j]);

		printf("\n");

	}

	return 0;
}
