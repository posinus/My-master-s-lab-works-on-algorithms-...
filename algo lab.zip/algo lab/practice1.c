#include<stdio.h>
#include<stdlib.h>

typedef struct Tree
{
	int key;
	struct Tree *left,*right;
}NODE;
 
 NODE *root=NULL;
 NODE *stack[100];
 int top=-1;
 
void createB(int k)
{
	NODE *p=(NODE *)malloc(sizeof(NODE));
	
	p->key=k;
	p->left=p->right=NULL;
	if(!root)
	{
		root=p;
		return;
	}
	NODE *q=root,*r=NULL;
	int ch;
	while(q)
	{
		r=q;
		printf("\n Enter choice::\t");
		scanf("%d",&ch);
		if(ch)
		{
			q=q->right;
		}
	    else
	    	q=q->left;	    
	}
	if(ch)
	{
		r->right=p;
		
	}
	else
		r->left=p; 
		
}
void push(NODE *element)
{
	top++;
	stack[top]=element;
}
NODE *pop()
{
	if(top==-1)
	return NULL;
	return stack[top--];
}
void inorder()
{
	NODE *p=root;
	while(p!=NULL || top!=-1)
	{
		while(p)
		{
			push(p);
			printf("%d ",p->key);
			p= p->left;
			
		}
		p=pop();
		
		p= p->right;
	}
}

int main()
{
	int n,k,i;
	printf("\n Enter the number of no of elements::");
	scanf("%d",&n);
	printf("\n Enter the value for the item ");
    for (i=0;i<n;i++)
	{	
	scanf("%d",&k);
	createB(k);
	}
	printf("\n The preorder traversal is::\t");
	inorder();
	return 0;
}
