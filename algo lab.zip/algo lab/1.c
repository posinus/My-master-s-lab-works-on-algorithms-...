#include <stdio.h>
#include <stdlib.h>

int main() {
    int size;

    // Read the size of the array from the user
    printf("Enter the size of the array: ");
    scanf("%d", &size);

    // Dynamically allocate memory for the array
    int *array = (int *)malloc(size * sizeof(int));

    // Check if memory allocation was successful
    if (array == NULL) {
        printf("Memory allocation failed. Exiting...\n");
        return 1;
    }

    // Read values from stdin and calculate the sum
    int sum = 0;
    int i;
    printf("Enter %d integers:\n", size);
    for ( i = 0; i < size; i++) {
        scanf("%d", &array[i]);
        sum += array[i];
    }

    // Print the sum
    printf("Sum of elements: %d\n", sum);

    // Free the dynamically allocated memory
    free(array);

    return 0;
}

