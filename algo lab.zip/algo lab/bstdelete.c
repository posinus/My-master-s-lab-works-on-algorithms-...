#include<stdio.h>
#include<stdlib.h>
int top=-1;
typedef struct tree{
	int key;
	struct tree *left,*right;
	}Node;

typedef struct pc{
	Node *parent,*child;
	}nodesearch;

Node *stack[100];
Node *root = NULL;

void create_tree(int k){
	Node *p=(Node*)malloc(sizeof(Node));
	Node *q=root,*r;
	p->key=k;
	p->left=p->right=NULL;
	if(!root){
		root=p;
		return;
	}
	while(q){
		r=q;
		if(k>q->key)
			q=q->right;
		else
			q=q->left;
	}
	if(k>r->key)
		r->right=p;
	else
		r->left=p;
}


void push(Node *element){
	stack[++top]=element;
}

Node* pop(){
	if(top==-1)
     	return NULL;
     return stack[top--];  
}

void traverse(){
	Node *p=root;
	while(p!=NULL || top!=-1){
		while(p){
			push(p);
			p=p->left;
		}
		p=pop();
		printf("%d ",p->key);
		p=p->right;
	}
	printf("\n");
}

nodesearch* search(int k){
	Node* loc = root;
	Node* ploc=loc;
	while(loc!=NULL && loc->key!=k){
	ploc= loc;
	if(loc->key>k)
		loc=loc->left;
	else
		loc=loc->right;
	}
	nodesearch *p=(nodesearch*)malloc(sizeof(nodesearch));
	p->parent = ploc;
	p->child = loc;	
	return p;
}

void deletion(int k){
	Node *temp,*prev = NULL;
	nodesearch *s =search(k);
	Node *parent = s->parent;
	Node *child = s->child;
	if(child!=NULL){
		if(!(child->left) && !(child->right)){
			if(parent->right == child)
				parent->right=NULL;
			else
				parent->left=NULL;
		}
		else if(!(child->left) || !(child->right)){
			if(child->left==NULL)
				temp = child->right;
			else
				temp = child->left;
			if(child==root)
				root = temp;
			if(parent->right == child)
				parent->right=temp;
			else
				parent->left=temp;
			free(child);
		}
		else{
				temp = child->right;
				while(temp->left!=NULL){
					prev = temp; temp = temp->left;
				}
				if(prev == NULL) 
					child->right = temp->right;
				else 
					prev->left = temp->right;
				child->key = temp->key;
				free(temp);
		}
	}
	else 
		printf("Data entered does not exist.");
	
}

int main(){
	int k,n,n1;
	printf("Enter the number of nodes: ");
	scanf("%d",&n);
	while(n>0)
	{
		printf("Enter the value of node: ");
		scanf("%d",&k);
		create_tree(k);
		n--;
	}
	printf("Enter the key to delete: ");
	scanf("%d",&n1);
	printf("\nTree before deletion: \n");
	traverse();
	deletion(n1);
	printf("\nTree after deletion: \n");
	traverse();
return 0;
}
