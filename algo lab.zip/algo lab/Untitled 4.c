#include <stdio.h>
#include <stdlib.h>

// Structure to represent an item
struct Item {
    int value;
    int weight;
};

// Function to compare items by their value-to-weight ratio
int compare(const void* a, const void* b) {
    double ratio1 = (double)((struct Item*)a)->value / ((struct Item*)a)->weight;
    double ratio2 = (double)((struct Item*)b)->value / ((struct Item*)b)->weight;
    if (ratio1 < ratio2)
        return 1;
    else if (ratio1 > ratio2)
        return -1;
    else
        return 0;
}

// Function to solve the Fractional Knapsack Problem
void fractionalKnapsack(struct Item items[], int n, int capacity) {
    // Sort items by value-to-weight ratio in non-increasing order
    qsort(items, n, sizeof(struct Item), compare);

    double totalValue = 0.0;  // Total value in the knapsack
    int currentWeight = 0;    // Current weight in the knapsack
    int i = 0;                // Index for items array

    while (i < n && currentWeight < capacity) {
        // If adding the current item won't exceed the capacity, add it
        if (currentWeight + items[i].weight <= capacity) {
            currentWeight += items[i].weight;
            totalValue += items[i].value;
        } else {
            // Add a fraction of the current item to fill the knapsack to capacity
            int remainingWeight = capacity - currentWeight;
            totalValue += (double)remainingWeight / items[i].weight * items[i].value;
            break; // The knapsack is now full
        }
        i++;
    }

    printf("Maximum value in the knapsack = %.2lf\n", totalValue);
}

int main() {
    int n; // Number of items
    int capacity; // Knapsack capacity

    printf("Enter the number of items: ");
    scanf("%d", &n);

    printf("Enter the knapsack capacity: ");
    scanf("%d", &capacity);

    struct Item items[n];
  	int i;
    for ( i = 0; i < n; i++) {
        printf("Enter the value and weight of item %d: ", i + 1);
        scanf("%d %d", &items[i].value, &items[i].weight);
    }

    fractionalKnapsack(items, n, capacity);

    return 0;
}

