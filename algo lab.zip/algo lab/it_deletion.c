#include <stdio.h>
#include <stdlib.h>

int top = -1;

typedef struct Tree {
	int key;
	struct Tree *left, *right;
}NODE;

typedef struct PC {
	struct PC *parent, *child;
}s;

NODE *stack[100];

NODE *root=NULL;

void create(int k) {
	NODE *p=(NODE*)malloc(sizeof(NODE));
	NODE *q=root, *r;
	p->key=k;
	p->left=p->right=NULL;
	if(!root){
		root=p;
		return;
	}
	while(q){
		r=q;
		if(k>q->key) q=q->right;
		else q=q->left;
	}
	if(k>r->key) r->right=p;
	else r->left=p;
}

void push(NODE *element) {
	top++;
	stack[top] = element;
}

NODE* pop() {
	if(top==-1) return NULL;
	return stack[top--];
}

void inordertraversal() {
	NODE *p = root;
	while(p!=NULL || top!=-1) {
		while(p) {
			push(p);
			p=p->left;
		}
		p = pop();
		printf("%d ", p->key);
		p=p->right;
	}
}

s* search(int k) {
	NODE *loc = root;
	NODE *ploc;
	while(loc!=NULL && loc->key!=k) {
		ploc = loc;
		if(k>loc->key) loc=loc->right;
		else loc=loc->left;
	}
	s *p=(s*)malloc(sizeof(s));
	p->child=loc;
	p->parent=ploc; 
	return p;
}

NODE* del(NODE* root, int n) {
	s *p = search(n);
	NODE *x = p->parent;
	NODE *y = p->child;
	if(y!=NULL) {
		if(!(y->left) && !(y->right)) {
			if(x->left->key == n) { x->left = NULL; free(y);}
			else {x->right = NULL; free(y);}
		}
		else if(!(y->left) && y->right){
			if(x->left->key == n) {x->left = y->right;free(y);}
			else{x->right = y->right; free(y);}
		}
		else if(y->left && !(y->right)){
			if(x->left->key == n) {x->left = y->left;free(y);}
			else{x->right = y->left; free(y);}
		}
		else{
				NODE *prev = NULL, *temp;
				temp = y->right;
				while(temp->left!=NULL){prev = temp; temp = temp->left;}
				if(prev == NULL) y->right = temp->right; 
				else prev->left = temp->right;
				y->key = temp->key;
				free(temp);
		}
	}
	else printf("Data Entered does not exist.\n");
	return root;
}

int main() {
	int n, n1, i;
	printf("Enter the number of elements : ");
	scanf("%d", &n);
	while(n>0){
		printf("Enter Element : ");
		scanf("%d", &i);
		create(i);
		n--;
	}
	printf("Enter Element to be deleted: ");
	scanf("%d", &n1);
	del(root,n1);
	inordertraversal();
	return 0;
}
