#include <stdio.h>

void swap(int *x, int *y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}

int partition(int a[], int low, int high) {
	int i;
	swap(&a[low],&a[(low+high)/2]);
    int pivotkey = a[low];
    int pivotloc = low;

    for ( i = low + 1; i <= high; i++) {
        if (a[i] < pivotkey) {
            pivotloc++;
            swap( &a[pivotloc],&a[i]);
        }
    }
    swap(&a[low], &a[pivotloc]);
    return pivotloc;
}

int qsort(int a[], int low, int high,int k) {
    if (low < high) {
        int pivotloc = partition(a, low, high);
        if(k==pivotloc)
        return a[k];
		else if(k<pivotloc)      
        qsort(a, low, pivotloc - 1,k);
        else
        qsort(a, pivotloc + 1, high,k);
    }
    return -1;
}

int main() {
    int n,i;
    int k;
    printf("\n Enter the size of the array::\n");
    scanf("%d", &n);
printf("\n Enter the index to find Kth smallest element::\n");
    scanf("%d", &k);

    int a[n];  // Declare an array of size n
    printf("\n Enter the elements of the array::\n");
    for ( i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    qsort(a, 0, n - 1,k);
    printf("\n The kth smallest element is::%d",a[k]);
    printf("\n");

}

