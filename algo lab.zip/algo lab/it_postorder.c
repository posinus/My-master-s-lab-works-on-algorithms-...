#include <stdio.h>
#include <stdlib.h>

int top1 = -1;
int top = -1;

typedef struct Tree {
	int key;
	struct Tree *left, *right;
}NODE;

NODE *stack1[100];
NODE *stack[100];

NODE *root=NULL;

void create(int k) {
	NODE *p=(NODE*)malloc(sizeof(NODE));
	NODE *q=root, *r;
	p->key=k;
	p->left=p->right=NULL;
	if(!root){
		root=p;
		return;
	}
	while(q){
		r=q;
		if(k>q->key) q=q->right;
		else q=q->left;
	}
	if(k>r->key) r->right=p;
	else r->left=p;
}

void push(NODE *element, int v) {
	if(v==1) stack[++top] = element;
	else stack1[++top1] = element;
}

NODE* pop(int v) {
	if(v==1) {
		if(top==-1) return NULL;
		return stack[top--];
	}
	if(v==2) {
		if(top1==-1) return NULL;
		return stack1[top1--];
	}
}

void postordertraversal() {
	NODE *p = root;
	NODE *p1;
	push(p, 1);
	while(top!=-1) {
		p1 = pop(1);
		push(p1, 2);
		if(p1->left != NULL) push(p1->left, 1);
		if(p1->right != NULL) push(p1->right, 1);
	}
	
	while(top1!=-1) {
		p1 = pop(2);
		printf("%d ", p1->key);
	}
}

int main() {
	int n, i;
	printf("Enter the number of elements : ");
	scanf("%d", &n);
	while(n>0){
		printf("Enter Element : ");
		scanf("%d", &i);
		create(i);
		n--;
	}
	postordertraversal();
	return 0;
}
