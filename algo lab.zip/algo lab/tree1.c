#include<stdio.h>
#include<stdlib.h>

typedef struct Tree {
    int key;
    struct Tree *left, *right;
} NODE;

NODE *root = NULL;

void createB(int k) {
    NODE *p = (NODE *)malloc(sizeof(NODE));
    NODE *q = root, *r = NULL;
    int ch;

    p->key = k;
    p->left = p->right = NULL;

    if (!root) {
        root = p;
        return;
    }

    while (q) {
        r = q;
        printf("Choose 0/1: ");
        scanf("%d", &ch);

        if (ch) {
            q = q->right;
        } else {
            q = q->left;
        }
    }5

    if (ch) {
        r->right = p;
    } else {
        r->left = p;
    }
}

void inorder(NODE *root) {
    if (root) {
        inorder(root->left);
        printf("%d ", root->key); // Added space after each number
        inorder(root->right);
    }
}

int main() {
    int n, k, i;
    printf("\nEnter the number of elements: ");
    scanf("%d", &n);
    printf("\nEnter the elements: ");
    for (i = 0; i < n; i++) {
        scanf("%d", &k);
        createB(k);
    }
    
    printf("\nInorder traversal of the tree: ");
    inorder(root);
    printf("\n");
    
    return 0;
}

