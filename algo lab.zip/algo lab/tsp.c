#include <stdio.h>
#define size 5
#define inf 999

void copyMatrix(int arr[size][size], int matrix[size][size]) {
	int i, j;
	for(i=0;i<size;i++) {
		for(j=0;j<size;j++) {
			arr[i][j] = matrix[i][j];
		}
	}
}

void printMatrix(int matrix[size][size]) {
	int i, j;
	for(i=0;i<size;i++) {
		for(j=0;j<size;j++) {
			printf("%d ", matrix[i][j]);
		}
		printf("\n");
	}
}

int reduce(int matrix[size][size]) {
	int l=0, i, j, min;
	// ROW
	for(i=0;i<size;i++) {
		min=inf;
		for(j=0;j<size;j++) { // finding min value
			if(matrix[i][j] < min) min = matrix[i][j];
		}
		if (min>=(inf/2)) min = 0; 
		l += min;
		for(j=0;j<size;j++) { // subtracting min value
			matrix[i][j] -= min;
		}
	}
	
	// COL
	for(i=0;i<size;i++) {
		min=inf;
		for(j=0;j<size;j++) { // finding min value
			if(matrix[j][i] < min) min = matrix[j][i];
		}
		if (min>=(inf/2)) min = 0; 
		l += min;
		for(j=0;j<size;j++) { // subtracting min value
			matrix[j][i] -= min;
		}
	}
	
	return l;
}

int tsp(int matrix[size][size], int l) {
	int i, k=1, l1, mn=inf;
	printf("%d\n", l);
	
	int arr[size][size];
	copyMatrix(arr, matrix);
	while(k<size) {
		l1=0;
		for(i=0;i<size;i++) arr[0][i] = inf;
		for(i=0;i<size;i++) arr[i][k] = inf;
		arr[k][0] = inf;
		int l1 = reduce(arr) + matrix[0][k] + l;
		copyMatrix(arr, matrix);
		//printf("%d\n", l1);
		k++;
		if(mn>l1) mn=l1;
	}
	return mn;
	
}

int main() {
	int matrix[size][size] = { {inf,20,30,10,11}, {15,inf,16,4,2}, {3,5,inf,2,4}, {19,6,18,inf,3}, {16,4,7,16,inf} };
	int l = reduce(matrix);
	int cost = tsp(matrix, l);
	printf("%d\n", cost);
	return 0;
}









