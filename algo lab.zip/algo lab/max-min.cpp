#include<stdio.h>
int a[100];
void maxmin(int i,int j,int *max,int *min)
{
	int max1,min1,mid;
	if(i==j)
		{
			*max=*min=a[i];
		}
	else
		{
			if(i==j-1)
		{
		if(a[i]<a[j])
		{
			*max=a[j];
			*min=a[i];
		}
	else
		{
			*max=a[i];
			*min=a[j];
		}
		}
	else
		{
			mid=(i+j)/2;
			maxmin(i,mid,max,min);
			max1=*max;
			min1=*min;
			maxmin(mid+1,j,max,min);
			if(*max<max1)
			*max=max1;
			if(*min>min1)
			*min=min1;
		}
		}
		}
	int main()
	{
		int n;
		printf("\n Enter the size of the array::\t");
		scanf("%d",&n);
		printf("\n Enter the elements::\n");
		for(int i=0;i<n;i++)
		scanf("%d",&a[i]);
		int max=a[0];
		int min=a[0];
		maxmin(0,n-1,&max,&min);
		printf("\n The maximum of the array is::%d\n",max);
		printf("\nThe minimum of the array is::%d\n",min);
		return 0;
	}


