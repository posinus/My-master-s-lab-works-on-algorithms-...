#include <stdio.h>

void swap(int *x, int *y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}

int partition(int a[], int low, int high) {
	int i;
	swap(&a[low],&a[(low+high)/2]);
    int pivotkey = a[low];
    int pivotloc = low;

    for ( i = low + 1; i <= high; i++) {
        if (a[i] < pivotkey) {
            pivotloc++;
            swap( &a[pivotloc],&a[i]);
        }
    }
    swap(&a[low], &a[pivotloc]);
    return pivotloc;
}

void qsort(int a[], int low, int high) {
    if (low < high) {
        int pivotloc = partition(a, low, high);
        qsort(a, low, pivotloc - 1);
        qsort(a, pivotloc + 1, high);
    }
}

int main() {
    int n,i;
    printf("\n Enter the size of the array::\n");
    scanf("%d", &n);

    int a[n];  // Declare an array of size n
    printf("\n Enter the elements of the array::\n");
    for ( i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    
    qsort(a, 0, n - 1);  // Pass n - 1 as the high value for the last element index
    printf("\n The sorted array is::\n");
    for ( i = 0; i < n; i++) {
        printf("%d ", a[i]);  // Use %d instead of &a[i] to print array elements
    }
    printf("\n");
}

