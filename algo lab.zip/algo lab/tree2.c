#include<stdio.h>
#include<stdlib.h>

typedef struct Tree {
    int key;
    struct Tree *left, *right;
} NODE;

NODE *root = NULL;

void createB(int k) {
    NODE *p = (NODE *)malloc(sizeof(NODE));
    p->key = k;
    p->left = p->right = NULL;

    if (!root) {
        root = p; // If the tree is empty, set the new node as the root.
        return;
    }

    NODE *q = root, *r = NULL;

    while (q) {
        r = q;

        if (k > q->key) {
            q = q->right;
        } else {
            q = q->left;
        }
    }

    if (k > r->key) {
        r->right = p;
    } else {
        r->left = p;
    }
}

void inorder(NODE *root) {
    if (root) {
        inorder(root->left);
        printf("%d ", root->key); // Added space after each number
        inorder(root->right);
    }
}

int main() {
    int n, k, i;
    printf("\nEnter the number of elements: ");
    scanf("%d", &n);
    printf("\nEnter the elements: ");
    for (i = 0; i < n; i++) {
        scanf("%d", &k);
        createB(k);
    }
    
    printf("\nInorder traversal of the tree: ");
    inorder(root);
    printf("\n");
    
    return 0;
}

