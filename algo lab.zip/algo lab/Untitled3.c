#include <stdio.h>
#define MAX_STACK_SIZE 100

void swap(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void quickSortIterative(int arr[], int left, int right) {
    int stack[MAX_STACK_SIZE];
    int top = -1;

    stack[++top] = left;
    stack[++top] = right;

    while (top >= 0) {
        right = stack[top--];
        left = stack[top--];

        int pivotIndex = partition(arr, left, right);

        if (pivotIndex - 1 > left) {
            stack[++top] = left;
            stack[++top] = pivotIndex - 1;
        }

        if (pivotIndex + 1 < right) {
            stack[++top] = pivotIndex + 1;
            stack[++top] = right;
        }
    }
}

int partition(int arr[], int left, int right) {
    int pivot = arr[right];
    int i = (left - 1);
    int j;

    for ( j = left; j <= right - 1; j++) {
        if (arr[j] < pivot) {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }

    swap(&arr[i + 1], &arr[right]);
    return (i + 1);
}

int main() {
	int arr[100];
    int n,i;
    printf("\n Enter the size of the array::\n");
    scanf("%d", &n);

    int a[n];  // Declare an array of size n
    printf("\n Enter the elements of the array::\n");
    for ( i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    printf("Unsorted array: ");
    for ( i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    quickSortIterative(arr, 0, n - 1);

    printf("Sorted array: ");
    for ( i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}


