#include<stdio.h>
int a[100];
void merge(int a[],int low,int mid,int high)
{
     int i,j,k,n1,n2;
	 n1=mid-low+1;
	 n2=high-mid;
	 int l[n1],r[n2];
	 for(i=0;i<n1;i++)
	 	l[i]=a[low+i];
	 for(j=0;j<n2;j++)
	 	r[j]=a[mid+1+j];
	 i=j=0;
	 k=low;
	 while(i<n1&&j<n2)
	 {
	 	if(l[i]<=r[j])
	 	{
	 		a[k]=l[i];
	 		i++;
		 }
		 else
		 {
		 	a[k]=r[j];
		 	j++;
		 }
		 k++;
	 }
	 while(i<n1)
	 {
	 	a[k]=l[i];
	 	i++;
	 	k++;
	 }
	 while(j<n2)
	 {
	 	a[k]=r[j];
	 	j++;
	 	k++;
	 }
}
void mergeSort(int a[],int low,int high)
{
	if(low<high)
	{
		int mid=(low+high)/2;
		mergeSort(a,low,mid);
		mergeSort(a,mid+1,high);
		merge(a,low,mid,high);
	}
}
int main()
{
	int n;
	int i;
	printf("\nEnter the no::\t");
	scanf("%d",&n);
	printf("\nEnter the elements::\t");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);		
	}
	mergeSort(a,0,n-1);
	printf("\nThe sorted array is::");
	for(i=0;i<n;i++)
	{
		printf("%d\n",a[i]);		
	}
	return 0;
}
	 	
		
