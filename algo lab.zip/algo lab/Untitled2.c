#include <stdio.h>

void mergeSort(int a[], int beg, int end) {
    int s, l1, u1, u2, n, l, r;
    int i,j,k;
    n = end - beg + 1;
    int temp[100];
    for (s = 1; s < n; s *= 2) 
	{
        for (l1 = 0; l1 + s < n; l1 = l1 + 2 * s) 
		{
            u1 = l1 + s - 1;
            u2 = (u1 + s) < n ? u1 + s : n - 1;

            l = l1;
            r = u1 + 1;
            int k = 0;
            while (l <= u1 && r <= u2) {
                if (a[l] <= a[r]) {
                    temp[k++] = a[l++];
                } else {
                    temp[k++] = a[r++];
                }
            }

            while (l <= u1) {
                temp[k++] = a[l++];
            }
            while (r <= u2) {
                temp[k++] = a[r++];
            }

            for ( i = l1, j = 0; i <= u2; i++, j++) {
                a[i] = temp[j];
            }
        }
    }
}

void printArray(int a[], int n) {
	int i;
    for ( i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");
}

int main() {
    int a[] = { 12, 31, 25, 8, 32, 17, 40, 42 };
    int n = sizeof(a) / sizeof(a[0]);
    printf("Before sorting array elements are - \n");
    printArray(a, n);
    mergeSort(a, 0, n - 1);
    printf("After sorting array elements are - \n");
    printArray(a, n);
    return 0;
}

